/*
 * KaiConfig.java
 *
 * Created on November 18, 2004, 4:23 PM
 */

package pt.jkaiui.core;
import java.util.prefs.Preferences;
import java.io.File;
import java.util.Collections;
import java.util.Vector;
import java.awt.*;
import java.awt.datatransfer.*;
import pt.jkaiui.JKaiUI;

/**
 *
 * @author  pedro
 */
public class KaiConfig {
    
    private static final String PREFERENCES = "/pt/jkaiui";
    
    private static Preferences preferences;
    
    /** Holds value of the NTP server */
    private String NTPServer;
    
    /** Holds value of the avatar cache location */
    private String avatarCacheLocation;
    
    private int cacheDays;
    private boolean showTimestamps;
    private boolean sendStatsPermission;
    private boolean showServerStats;
    private boolean storeWindowSizePosition;
    private int WindowHeigth;
    private int WindowWidth;
    private int WindowX;
    private int WindowY;
    private boolean playMessageSound;
    
    /** Holds value of the avatar cache location */
    private boolean engineAutomaticallyDetected;
    
    /** Holds value of property tag. */
    private String tag;
    
    /** Holds value of property password. */
    private String password;
    
    /** Holds value of property host. */
    private String host;
    
    /** Holds value of property port. */
    private int port;
    
    private String BookmarksAtStart;


    //1:Allchat 2:AllPM  3:when PM open 4: friend
//    private int playSoundTiming;
    
    //
    private boolean HtmlUnicode;
    private boolean URLDecode;
    private boolean AutoHostSetting;
    private boolean AutoArenaMoving;
    
    private boolean AllLog;
    private boolean ChatLog;
    private boolean UserLog;
    private boolean RoomLog;
    private boolean FriendLog;
    private boolean MACLog;

    private String AllLogFile;
    private String ChatLogFile;
    private String UserLogFile;
    private String RoomLogFile;
    private String FriendLogFile;
    private String MACLogFile;
    
    private String AllLogPattern;
    private String ChatLogPattern;
    private String UserLogPattern;
    private String RoomLogPattern;
    private String FriendLogPattern;
    private String MACLogPattern;
 
    private boolean ShowLatestChat;
    private boolean HideSeverMessage;
    private int ChatFontSize;
    private int SystemFontSize;
    
    private boolean ChatSound;
    private boolean PMOpenSound;
    private boolean FriendPMSound;        
    private boolean FriendChatSound;                   
    private boolean FriendOnlineSound;
    private boolean ArenaPMSound;                                   
    private boolean ModeratorChatSound;
    private boolean SendSound;
    
    private String ChatSoundFile;
    private String PMOpenSoundFile;
    private String FriendPMSoundFile;        
    private String FriendChatSoundFile;                   
    private String FriendOnlineSoundFile;
    private String ArenaPMSoundFile;                                   
    private String ModeratorChatSoundFile;
    private String SendSoundFile;
            
    /** Creates a new instance of KaiConfig */
    public KaiConfig() {
    }

    ////////////////////////////
    ////   GETTERS
    //////////////
    
    /** Getter for property tag.
     * @return Value of property tag. */
    public String getTag() {
        return this.tag;
    }
    
    /** Getter for property password.
     * @return Value of property password. */
    public String getPassword() {
        return this.password;
    }
    
    /** Getter for property host.
     * @return Value of property host. */
    public String getHost() {
        return this.host;
    }
    
    /** Getter for property port.
     * @return Value of property port. */
    public int getPort() {
        return this.port;
    }
    
    /** Getter for property NTPServer.
     * @return Value of property NTPServer. */
    public String getNTPServer() {
        return this.NTPServer;
    }
    
    /** Getter for property AVATARCACHE.
     * @return Value of property AVATARCACHE. */
    public String getAvatarCacheLocation() {
        return this.avatarCacheLocation;
    }
    
    public boolean getEngineAutomaticallyDetected() {
        return this.engineAutomaticallyDetected;
    }
    
    public int getCacheDays() {
        return cacheDays;
    }
    
    public boolean getSendStatsPermission() {
        return sendStatsPermission;
    }
    
    public boolean getShowTimestamps() {
        return showTimestamps;
    }
    
    public String getBookmarksAtStart() {
        return BookmarksAtStart;
    }
    
    public boolean getShowServerStats() {
        return showServerStats;
    }
    
    public boolean getStoreWindowSizePosition() {
        return storeWindowSizePosition;
    }
    
    public int getWindowHeigth() {
        return WindowHeigth;
    }
    
    public int getWindowWidth() {
        return WindowWidth;
    }
    
    public int getWindowX() {
        return WindowX;
    }
    
    public int getWindowY() {
        return WindowY;
    }

    
    
    public boolean getPlayMessageSound() {
        return playMessageSound;
    }
 /*   
    public int getPlaySoundTiming(){
        return playSoundTiming;
    }
   */ 
    public boolean getHtmlUnicode() {
        return HtmlUnicode;
    }

    public boolean getURLDecode() {
        return URLDecode;
    }
    public boolean getAutoHostSetting() {
        return AutoHostSetting;
    }
    public boolean getAutoArenaMoving() {
        return AutoArenaMoving;
    }

    public boolean getShowLatestChat() {
        return ShowLatestChat;
    }

    public boolean getHideSeverMessage() {
        return HideSeverMessage;
    }
    
    
    public boolean getAllLog() {
        return AllLog;
    }

    public String getAllLogFile() {
        return AllLogFile;
    }

    public String getAllLogPattern() {
        return AllLogPattern;
    }

    public int getChatFontSize() {
        return ChatFontSize;
    }

    public boolean getChatLog() {
        return ChatLog;
    }

    public String getChatLogFile() {
        return ChatLogFile;
    }

    public String getChatLogPattern() {
        return ChatLogPattern;
    }

    public boolean getFriendLog() {
        return FriendLog;
    }

    public String getFriendLogFile() {
        return FriendLogFile;
    }

    public String getFriendLogPattern() {
        return FriendLogPattern;
    }

    public boolean getRoomLog() {
        return RoomLog;
    }

    public String getRoomLogFile() {
        return RoomLogFile;
    }

    public String getRoomLogPattern() {
        return RoomLogPattern;
    }

    public int getSystemFontSize() {
        return SystemFontSize;
    }

    public boolean getUserLog() {
        return UserLog;
    }

    public String getUserLogFile() {
        return UserLogFile;
    }
    
    public String getUserLogPattern() {
        return UserLogPattern;
    }

    public boolean getMACLog() {
        return MACLog;
    }

    public String getMACLogFile() {
        return MACLogFile;
    }

    public String getMACLogPattern() {
        return MACLogPattern;
    }

    
    public boolean getArenaPMSound() {
        return ArenaPMSound;
    }

    public String getArenaPMSoundFile() {
        return ArenaPMSoundFile;
    }

    public boolean getChatSound() {
        return ChatSound;
    }

    public String getChatSoundFile() {
        return ChatSoundFile;
    }

    public boolean getFriendChatSound() {
        return FriendChatSound;
    }

    public String getFriendChatSoundFile() {
        return FriendChatSoundFile;
    }

    public boolean getFriendOnlineSound() {
        return FriendOnlineSound;
    }

    public String getFriendOnlineSoundFile() {
        return FriendOnlineSoundFile;
    }

    public boolean getFriendPMSound() {
        return FriendPMSound;
    }

    public String getFriendPMSoundFile() {
        return FriendPMSoundFile;
    }

    public boolean getModeratorChatSound() {
        return ModeratorChatSound;
    }

    public String getModeratorChatSoundFile() {
        return ModeratorChatSoundFile;
    }

    public boolean getPMOpenSound() {
        return PMOpenSound;
    }

    public String getPMOpenSoundFile() {
        return PMOpenSoundFile;
    }
    
    public boolean getSendSound(){
        return SendSound;
    }
    public String getSendSoundFile(){
        return SendSoundFile;
    }
    
    ////////////////////////////
    ////   SETTERS
    //////////////
    
    /** Setter for property tag.
     * @param tag New value of property tag. */
    public void setTag(String tag) {
        this.tag = tag;
    }
    
    /** Setter for property password.
     * @param password New value of property password. */
    public void setPassword(String password) {
        this.password = password;
    }
    
    /** Setter for property host.
     * @param host New value of property host. */
    public void setHost(String host) {
        this.host = host;
    }
    
    /** Setter for property port.
     * @param port New value of property port. */
    public void setPort(int port) {
        this.port = port;
    }
    
    /** Setter for property NTPServer.
     * @param server New value of the NTPServer property*/
    public void setNTPServer(String server) {
        this.NTPServer = server;
    }
    
    public void setAvatarCacheLocation(String location) {
        this.avatarCacheLocation = location;
    }
    
    public void setEngineAutomaticallyDetected(boolean value) {
        this.engineAutomaticallyDetected = value;
    }
    
    public void setCacheDays(int days) {
        cacheDays = days;
    }
    
    public void setSendStatsPermission(boolean permission) {
        sendStatsPermission = permission;
    }
    
    public void setShowTimestamps(boolean value) {
        showTimestamps = value;
    }
    
    public void setShowServerStats(boolean value) {
        showServerStats = value;
    }
    
    public void setStoreWindowSizePosition(boolean value) {
        storeWindowSizePosition = value;
    }
    
    public void setPlayMessageSound(boolean value) {
        playMessageSound = value;
    }

    
   /* 
    public void setPlaySoundTiming(int playSoundTiming) {
        this.playSoundTiming = playSoundTiming;
    }
    */
    public void setHtmlUnicode(boolean HtmlUnicode) {
        this.HtmlUnicode = HtmlUnicode;
    }
    
    public void setURLDecode(boolean URLDecode) {
        this.URLDecode = URLDecode;
    }
    public void setAutoHostSetting(boolean AutoHostSetting) {
        this.AutoHostSetting = AutoHostSetting;
    }
    public void setAutoArenaMoving(boolean AutoArenaMoving){
        this.AutoArenaMoving = AutoArenaMoving;
    }    
    public void setShowLatestChat(boolean ShowLatestChat) {
        this.ShowLatestChat = ShowLatestChat;
    }
    public void setHideSeverMessage(boolean HideSeverMessage) {
        this.HideSeverMessage = HideSeverMessage;
    }

    
    public void setAllLog(boolean AllLog) {
        this.AllLog = AllLog;
    }

    public void setAllLogFile(String AllLogFile) {
        this.AllLogFile = AllLogFile;
    }

    public void setAllLogPattern(String AllLogPattern) {
        this.AllLogPattern = AllLogPattern;
    }

    public void setChatFontSize(int ChatFontSize) {
        this.ChatFontSize = ChatFontSize;
    }

    public void setChatLog(boolean ChatLog) {
        this.ChatLog = ChatLog;
    }

    public void setChatLogFile(String ChatLogFile) {
        this.ChatLogFile = ChatLogFile;
    }

    public void setChatLogPattern(String ChatLogPattern) {
        this.ChatLogPattern = ChatLogPattern;
    }

    public void setFriendLog(boolean FriendLog) {
        this.FriendLog = FriendLog;
    }

    public void setFriendLogFile(String FriendLogFile) {
        this.FriendLogFile = FriendLogFile;
    }

    public void setFriendLogPattern(String FriendLogPattern) {
        this.FriendLogPattern = FriendLogPattern;
    }

    public void setRoomLog(boolean RoomLog) {
        this.RoomLog = RoomLog;
    }

    public void setRoomLogFile(String RoomLogFile) {
        this.RoomLogFile = RoomLogFile;
    }

    public void setRoomLogPattern(String RoomLogPattern) {
        this.RoomLogPattern = RoomLogPattern;
    }

    public void setSystemFontSize(int SystemFontSize) {
        this.SystemFontSize = SystemFontSize;
    }

    public void setUserLog(boolean UserLog) {
        this.UserLog = UserLog;
    }

    public void setUserLogFile(String UserLogFile) {
        this.UserLogFile = UserLogFile;
    }

    public void setUserLogPattern(String UserLogPattern) {
        this.UserLogPattern = UserLogPattern;
    }

    public void setMACLog(boolean MACLog) {
        this.MACLog = MACLog;
    }

    public void setMACLogFile(String MACLogFile) {
        this.MACLogFile = MACLogFile;
    }

    public void setMACLogPattern(String MACLogPattern) {
        this.MACLogPattern = MACLogPattern;
    }
    
    
    
    public void setArenaPMSound(boolean ArenaPMSound) {
        this.ArenaPMSound = ArenaPMSound;
    }

    public void setArenaPMSoundFile(String ArenaPMSoundFile) {
        this.ArenaPMSoundFile = ArenaPMSoundFile;
    }

    public void setChatSound(boolean ChatSound) {
        this.ChatSound = ChatSound;
    }

    public void setChatSoundFile(String ChatSoundFile) {
        this.ChatSoundFile = ChatSoundFile;
    }

    public void setFriendChatSound(boolean FriendChatSound) {
        this.FriendChatSound = FriendChatSound;
    }

    public void setFriendChatSoundFile(String FriendChatSoundFile) {
        this.FriendChatSoundFile = FriendChatSoundFile;
    }

    public void setFriendOnlineSound(boolean FriendOnlineSound) {
        this.FriendOnlineSound = FriendOnlineSound;
    }

    public void setFriendOnlineSoundFile(String FriendOnlineSoundFile) {
        this.FriendOnlineSoundFile = FriendOnlineSoundFile;
    }

    public void setFriendPMSound(boolean FriendPMSound) {
        this.FriendPMSound = FriendPMSound;
    }

    public void setFriendPMSoundFile(String FriendPMSoundFile) {
        this.FriendPMSoundFile = FriendPMSoundFile;
    }

    public void setModeratorChatSound(boolean ModeratorChatSound) {
        this.ModeratorChatSound = ModeratorChatSound;
    }

    public void setModeratorChatSoundFile(String ModeratorChatSoundFile) {
        this.ModeratorChatSoundFile = ModeratorChatSoundFile;
    }

    public void setPMOpenSound(boolean PMOpenSound) {
        this.PMOpenSound = PMOpenSound;
    }

    public void setPMOpenSoundFile(String PMOpenSoundFile) {
        this.PMOpenSoundFile = PMOpenSoundFile;
    }
    
    public void setSendSound(boolean SendSound){
        this.SendSound = SendSound;
    }
    
    public void setSendSoundFile(String SendSoundFile){
        this.SendSoundFile = SendSoundFile;
    }
 
    
    public void readConfig(){
        
        preferences = Preferences.userRoot().node(PREFERENCES);
        
        this.setTag(preferences.get("TAG",""));
        this.setPassword(preferences.get("PASSWORD",""));
        this.setHost(preferences.get("HOST","127.0.0.1"));
        this.setPort(preferences.getInt("PORT",34522));
        this.setNTPServer(preferences.get("NTPSERVER", "ntp1.ptb.de"));
        this.setAvatarCacheLocation(preferences.get("AVATARCACHE",
        System.getProperty("user.home") + File.separator + ".java" + File.separator + ".jkaiui_cache"));
        this.setEngineAutomaticallyDetected(preferences.getBoolean("AUTOMATICALLYDETECTED", true));
        this.setCacheDays(preferences.getInt("CACHEDAYS", 3));
        this.setSendStatsPermission(preferences.getBoolean("ALLOWSTATISTICS", true));
        this.setShowTimestamps(preferences.getBoolean("SHOWTIMESTAMPS", false));
        this.BookmarksAtStart = preferences.get("BOOKMARKS", "");
        setStoreWindowSizePosition(preferences.getBoolean("STOREWINDOWSIZEPOSITION", false));
        setShowServerStats(preferences.getBoolean("SHOWSERVERSTATS", false));
        this.WindowHeigth = preferences.getInt("WINDOWHEIGTH", 500);
        this.WindowWidth = preferences.getInt("WINDOWWIDTH", 200);
        this.WindowX = preferences.getInt("WINDOWX", 0);
        this.WindowY = preferences.getInt("WINDOWY", 0);
        this.playMessageSound = preferences.getBoolean("PLAYMESSAGESOUND", true);
        
  //      this.playSoundTiming = preferences.getInt("PLAYSOUNDTIMING", 4);
        this.HtmlUnicode = preferences.getBoolean("HtmlEncode", true);
        this.URLDecode = preferences.getBoolean("URLDecode", true);
        this.AutoHostSetting = preferences.getBoolean("AutoHostSetting", false);
        this.AutoArenaMoving = preferences.getBoolean("AutoArenaMoving", false);
        
        this.AllLog = preferences.getBoolean("AllLog",false);
        this.ChatLog = preferences.getBoolean("ChatLog", false);
        this.UserLog = preferences.getBoolean("UserLog", false);
        this.RoomLog = preferences.getBoolean("RoomLog", false);
        this.FriendLog = preferences.getBoolean("FriendLog",false);
        this.MACLog = preferences.getBoolean("MACLog", false);
        
        this.AllLogFile = preferences.get("AllLogFile", "./log/Alllog-%Y%M%D.txt");
        this.ChatLogFile = preferences.get("ChatLogFile", "./log/Chatlog-%Y%M%D.txt");
        this.UserLogFile = preferences.get("UserLogFile", "./log/Userlog-%Y%M%D.txt");
        this.RoomLogFile = preferences.get("RoomLogFile", "./log/Roomlog-%Y%M%D.txt");
        this.FriendLogFile = preferences.get("FriendLogFile", "./log/Friendlog-%Y%M%D.txt");
        this.MACLogFile = preferences.get("MACLogFile", "./log/MAClog-%Y%M%D.txt");

        this.AllLogPattern = preferences.get("AllLogPattern", "%T;%M");
        this.ChatLogPattern = preferences.get("ChatLogPattern", "%T;%K;%R;%S;%M");
        this.UserLogPattern = preferences.get("UserLogPattern", "%N");
        this.RoomLogPattern = preferences.get("RoomLogPattern", "%V;%C;%S;%P;%M;%D");
        this.FriendLogPattern = preferences.get("FriendLogPattern", "%T;%K;%N");
        this.MACLogPattern = preferences.get("MACLogPattern", "%N;%A");

        this.ShowLatestChat = preferences.getBoolean("ShowLatestChat", true);
        this.HideSeverMessage = preferences.getBoolean("HideServerMessage", false);
        this.ChatFontSize = preferences.getInt("ChatFontSize", 12);
        this.SystemFontSize = preferences.getInt("SystemFontSize", 10);
        
        this.ChatSound = preferences.getBoolean("ChatSound", false);
        this.PMOpenSound = preferences.getBoolean("PMOpenSound", false);
        this.FriendPMSound = preferences.getBoolean("FriendPMSound", false);
        this.FriendChatSound = preferences.getBoolean("FriendChatSound", false);
        this.FriendOnlineSound = preferences.getBoolean("FriendOnlineSound", false);
        this.ArenaPMSound = preferences.getBoolean("ArenaPMSound", false);
        this.ModeratorChatSound = preferences.getBoolean("ModeratorChatSound", false);
        this.SendSound = preferences.getBoolean("SendSound", false);

        this.ChatSoundFile = preferences.get("ChatSoundFile", "default");
        this.PMOpenSoundFile = preferences.get("PMOpenSoundFile", "default");
        this.FriendPMSoundFile = preferences.get("FriendPMSoundFile", "default");
        this.FriendChatSoundFile = preferences.get("FriendChatSoundFile", "default");
        this.FriendOnlineSoundFile = preferences.get("FriendOnlineSoundFile", "default");
        this.ArenaPMSoundFile = preferences.get("ArenaPMSoundFile", "default");
        this.ModeratorChatSoundFile = preferences.get("ModeratorChatSoundFile", "default");
        this.SendSoundFile = preferences.get("SendSoundFile", "default");
    }
    
    public void saveConfig(){
        
        preferences.put("TAG",this.getTag());
        preferences.put("PASSWORD",this.getPassword());
        preferences.put("HOST",this.getHost());
        preferences.putInt("PORT",this.getPort());
        preferences.put("NTPSERVER", this.getNTPServer());
        preferences.putBoolean("AUTOMATICALLYDETECTED", this.getEngineAutomaticallyDetected());
        preferences.putInt("CACHEDAYS", this.getCacheDays());
        preferences.putBoolean("ALLOWSTATISTICS", this.getSendStatsPermission());
        preferences.putBoolean("SHOWTIMESTAMPS", this.getShowTimestamps());
        preferences.putBoolean("SHOWSERVERSTATS", this.getShowServerStats());
        preferences.putBoolean("STOREWINDOWSIZEPOSITION", this.getStoreWindowSizePosition());
        preferences.putBoolean("PLAYMESSAGESOUND", this.getPlayMessageSound());
        
 //       preferences.putInt("PLAYSOUNDTIMING", this.getPlaySoundTiming());
        preferences.putBoolean("HtmlUnicode", this.getHtmlUnicode());
        preferences.putBoolean("URLDecode", this.getURLDecode());
        preferences.putBoolean("AutoHostSetting", this.getAutoHostSetting());
        preferences.putBoolean("AutoArenaMoving", this.getAutoArenaMoving());
        
        preferences.putBoolean("AllLog", this.getAllLog());
        preferences.putBoolean("ChatLog", this.getChatLog());
        preferences.putBoolean("UserLog", this.getUserLog());
        preferences.putBoolean("RoomLog", this.getRoomLog());
        preferences.putBoolean("FriendLog", this.getFriendLog());
        preferences.putBoolean("MACLog", this.getMACLog());
        
        preferences.put("AllLogFile", this.getAllLogFile());
        preferences.put("ChatLogFile", this.getChatLogFile());
        preferences.put("UserLogFile", this.getUserLogFile());
        preferences.put("RoomLogFile", this.getRoomLogFile());
        preferences.put("FriendLogFile", this.getFriendLogFile());
        preferences.put("MACLogFile", this.getMACLogFile());
        
        preferences.put("AllLogPattern", this.getAllLogPattern());
        preferences.put("ChatLogPattern", this.getChatLogPattern());
        preferences.put("UserLogPattern", this.getUserLogPattern());
        preferences.put("RoomLogPattern", this.getRoomLogPattern());
        preferences.put("FriendLogPattern", this.getFriendLogPattern());
        preferences.put("MACLogPattern", this.getMACLogPattern());

        preferences.putBoolean("ShowLatestChat", this.getShowLatestChat());
        preferences.putBoolean("HideServerMessage", this.getHideSeverMessage());
        preferences.putInt("ChatFontSize", this.getChatFontSize());
        preferences.putInt("SystemFontSize", this.getSystemFontSize());
        
        preferences.putBoolean("ChatSound", this.getChatSound());
        preferences.putBoolean("PMOpenSound", this.getPMOpenSound());
        preferences.putBoolean("FriendPMSound", this.getFriendPMSound());
        preferences.putBoolean("FriendChatSound", this.getFriendChatSound());
        preferences.putBoolean("FriendOnlineSound", this.getFriendOnlineSound());
        preferences.putBoolean("ArenaPMSound", this.getArenaPMSound());
        preferences.putBoolean("ModeratorChatSound", this.getModeratorChatSound());
        preferences.putBoolean("SendSound", this.getSendSound());

        preferences.put("ChatSoundFile", this.getChatSoundFile());
        preferences.put("PMOpenSoundFile", this.getPMOpenSoundFile());
        preferences.put("FriendPMSoundFile", this.getFriendPMSoundFile());
        preferences.put("FriendChatSoundFile", this.getFriendChatSoundFile());
        preferences.put("FriendOnlineSoundFile", this.getFriendOnlineSoundFile());
        preferences.put("ArenaPMSoundFile", this.getArenaPMSoundFile());
        preferences.put("ModeratorChatSoundFile", this.getModeratorChatSoundFile());
        preferences.put("SendSoundFile", this.getSendSoundFile());
    }
    
    public void resetConfig(){
        this.setTag("");
        this.setPassword("");
        this.setHost("127.0.0.1");
        this.setPort(34522);
        this.setNTPServer("ntp1.ptb.de");
        this.setAvatarCacheLocation(System.getProperty("user.home") + File.separator + ".java" + File.separator + ".jkaiui_cache");
        this.setEngineAutomaticallyDetected(true);
        this.setCacheDays(3);
        this.setSendStatsPermission(true);
        this.setShowTimestamps(false);
        this.BookmarksAtStart = "";
        setStoreWindowSizePosition(false);
        setShowServerStats(false);
        this.WindowHeigth = 500;
        this.WindowWidth = 200;
        this.WindowX = 0;
        this.WindowY = 0;
        this.playMessageSound = true;
        
  //      this.playSoundTiming = 4;
        this.HtmlUnicode = true;
        this.URLDecode = true;
        this.AutoHostSetting = false;
        this.AutoArenaMoving = false;
        
        this.AllLog = false;
        this.ChatLog = false;
        this.UserLog = false;
        this.RoomLog = false;
        this.FriendLog = false;
        this.MACLog = false;
        
        this.AllLogFile = "./log/Alllog-%Y%M%D.txt";
        this.ChatLogFile = "./log/Chatlog-%Y%M%D.txt";
        this.UserLogFile = "./log/Userlog-%Y%M%D.txt";
        this.RoomLogFile = "./log/Roomlog-%Y%M%D.txt";
        this.FriendLogFile = "./log/Friendlog-%Y%M%D.txt";
        this.MACLogFile = "./log/MAClog-%Y%M%D.txt";

        this.AllLogPattern = "%T;%M";
        this.ChatLogPattern = "%T;%K;%R;%S;%M";
        this.UserLogPattern = "%N";
        this.RoomLogPattern = "%V;%C;%S;%P;%M;%D";
        this.FriendLogPattern = "%T;%K;%N";
        this.MACLogPattern = "%N;%A";

        this.ShowLatestChat = true;
        this.HideSeverMessage = false;
        this.ChatFontSize = 12;
        this.SystemFontSize = 10;
        
        this.ChatSound = false;
        this.PMOpenSound = false;
        this.FriendPMSound = false;
        this.FriendChatSound = false;
        this.FriendOnlineSound = false;
        this.ArenaPMSound =  false;
        this.ModeratorChatSound =  false;
        this.SendSound = false;

        this.ChatSoundFile = "default";
        this.PMOpenSoundFile = "default";
        this.FriendPMSoundFile = "default";
        this.FriendChatSoundFile = "default";
        this.FriendOnlineSoundFile = "default";
        this.ArenaPMSoundFile = "default";
        this.ModeratorChatSoundFile =  "default";
        this.SendSoundFile =  "default";
        saveConfig();
    } 
    
    public void copytoClipboard() {
        preferences = Preferences.userRoot().node(PREFERENCES);
        
        StringBuffer strbuf = new StringBuffer("Setting infomation \n\n");//�ۑ�����ݒ���
        
        strbuf.append(JKaiUI.getVersion()+"\n");
        
//        strbuf.append("TAG:"+preferences.get("TAG","")+"\n");
//        strbuf.append("PASSWORD:"+preferences.get("PASSWORD","")+"\n");
        strbuf.append("\nOriginal Setting\n\n");
        strbuf.append("HOST:" + preferences.get("HOST", "127.0.0.1") + "\n");
        strbuf.append("PORT:" + preferences.getInt("PORT", 34522) + "\n");
        strbuf.append("NTPSERVER:" + preferences.get("NTPSERVER", "ntp1.ptb.de") + "\n");
        strbuf.append("AVATARCACHE" + preferences.get("AVATARCACHE",
                System.getProperty("user.home:") + File.separator + ".java" + File.separator + ".jkaiui_cache") + "\n");
        strbuf.append("AUTOMATICALLYDETECTED:" + preferences.getBoolean("AUTOMATICALLYDETECTED", true) + "\n");
        strbuf.append("CACHEDAYS:" + preferences.getInt("CACHEDAYS", 3) + "\n");
        strbuf.append("ALLOWSTATISTICS:" + preferences.getBoolean("ALLOWSTATISTICS", true) + "\n");
        strbuf.append("SHOWTIMESTAMPS:" + preferences.getBoolean("SHOWTIMESTAMPS", false) + "\n");
        strbuf.append("BOOKMARKS:" + preferences.get("BOOKMARKS", "") + "\n");
        strbuf.append("STOREWINDOWSPOSITION:" + preferences.getBoolean("STOREWINDOWSIZEPOSITION", false) + "\n");
        strbuf.append("SHOWSERVERSTATS:" + preferences.getBoolean("SHOWSERVERSTATS", false) + "\n");
        strbuf.append("WINDOWHEIGTH:" + preferences.getInt("WINDOWHEIGTH", 500) + "\n");
        strbuf.append("WINDOWWIDTH:" + preferences.getInt("WINDOWWIDTH", 200) + "\n");
        strbuf.append("WINDOWX:" + preferences.getInt("WINDOWX", 0) + "\n");
        strbuf.append("WINDOWY:" + preferences.getInt("WINDOWY", 0) + "\n");
        strbuf.append("PLAYMESSAGESOUND:" + preferences.getBoolean("PLAYMESSAGESOUND", true) + "\n");

        //    strbuf.append(":"+preferences.getInt("PLAYSOUNDTIMING", 4))+"\n");
        strbuf.append("\nOther Setting\n\n");
        strbuf.append("HtmlEncode:" + preferences.getBoolean("HtmlEncode", true) + "\n");
        strbuf.append("URLDecode:" + preferences.getBoolean("URLDecode", true) + "\n");
        strbuf.append("AutoHostSetting:" + preferences.getBoolean("AutoHostSetting", false) + "\n");
        strbuf.append("AutoArenaMoving:" + preferences.getBoolean("AutoArenaMoving", false) + "\n");

        strbuf.append("\nLog File Setting\n\n");
        strbuf.append("AllLog:" + preferences.getBoolean("AllLog", false) + "\n");
        strbuf.append("ChatLog:" + preferences.getBoolean("ChatLog", false) + "\n");
        strbuf.append("UserLog:" + preferences.getBoolean("UserLog", false) + "\n");
        strbuf.append("RoomLog:" + preferences.getBoolean("RoomLog", false) + "\n");
        strbuf.append("FriendLog:" + preferences.getBoolean("FriendLog", false) + "\n");
        strbuf.append("MACLog:" + preferences.getBoolean("MACLog", false) + "\n");

        strbuf.append("AllLogFile:"+preferences.get("AllLogFile", "./log/Alllog-%Y%M%D.txt")+"\n");
        strbuf.append("ChatLogFile:"+preferences.get("ChatLogFile", "./log/Chatlog-%Y%M%D.txt")+"\n");
        strbuf.append("UserLogFile:"+preferences.get("UserLogFile", "./log/Userlog-%Y%M%D.txt")+"\n");
        strbuf.append("RoomLogFile:"+preferences.get("RoomLogFile", "./log/Roomlog-%Y%M%D.txt")+"\n");
        strbuf.append("FriendLogFile:"+preferences.get("FriendLogFile", "./log/Friendlog-%Y%M%D.txt")+"\n");
        strbuf.append("MACLogFile:" + preferences.get("MACLogFile", "./MAClog-%Y%M%D.txt")+"\n");
        
        strbuf.append("AllLogPattern:"+preferences.get("AllLogPattern", "%T;%M")+"\n");
        strbuf.append("ChatLogPattern:"+preferences.get("ChatLogPattern", "%T;%K;%R;%S;%M")+"\n");
        strbuf.append("UserLogPattern:"+preferences.get("UserLogPattern", "%N")+"\n");
        strbuf.append("RoomLogPatten:"+preferences.get("RoomLogPattern", "%V;%C;%S;%P;%M;%D")+"\n");
        strbuf.append("FriendLogPatten:"+preferences.get("FriendLogPattern", "%T;%K;%N")+"\n");
        strbuf.append("MACLogPattern:"+preferences.get("MACLogPattern", "%N;%A")+"\n");

        strbuf.append("\nChat Setting\n\n");
        strbuf.append("ShowLatestChat:"+preferences.getBoolean("ShowLatestChat", true)+"\n");
        strbuf.append("HideServerMessage:"+preferences.getBoolean("HideServerMessage", false)+"\n");
        strbuf.append("ChatFontSize:" + preferences.getInt("ChatFontSize", 12) + "\n");
        strbuf.append("SystemFontSize:" + preferences.getInt("SystemFontSize", 10) + "\n");

        strbuf.append("\nSound Setting\n\n");
        strbuf.append("ChatSound:" + preferences.getBoolean("ChatSound", false) + "\n");
        strbuf.append("PMOpenSound:" + preferences.getBoolean("PMOpenSound", false) + "\n");
        strbuf.append("FriendPMSound:" + preferences.getBoolean("FriendPMSound", false) + "\n");
        strbuf.append("FriendChatSound:"+preferences.getBoolean("FriendChatSound", false)+"\n");
        strbuf.append("FriendOnlineSound:"+preferences.getBoolean("FriendOnlineSound", false)+"\n");
        strbuf.append("ArenaPMSound:"+preferences.getBoolean("ArenaPMSound", false)+"\n");
        strbuf.append("ModeratorChatSound:"+preferences.getBoolean("ModeratorChatSound", false)+"\n");
        strbuf.append("SendSound:"+preferences.getBoolean("SendSound", false)+"\n");

        strbuf.append("ChatSoundFile:"+preferences.get("ChatSoundFile", "default")+"\n");
        strbuf.append("PMOpenSoundFile:"+preferences.get("PMOpenSoundFile", "default")+"\n");
        strbuf.append("FriendPMSoundFile:"+preferences.get("FriendPMSoundFile", "default")+"\n");
        strbuf.append("FriendChatSoundFile:"+preferences.get("FriendChatSoundFile", "default")+"\n");
        strbuf.append("FriendOnlineSoundFile:"+preferences.get("FriendOnlineSoundFile", "default")+"\n");
        strbuf.append("ArenaPMSoundFile:"+preferences.get("ArenaPMSoundFile", "default")+"\n");
        strbuf.append("ModeratorChatSoundFile:"+preferences.get("ModeratorChatSoundFile", "default")+"\n");
        strbuf.append("SendSoundFile:"+preferences.get("SendSoundFile", "default")+"\n");

        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        StringSelection selection = new StringSelection(strbuf.toString());
        clipboard.setContents(selection, null);
    }
    
    public void saveBookmarks(Vector Bookmarks) {
        Collections.sort(Bookmarks);
        preferences.put("BOOKMARKS", Bookmarks.toString());
        try {
            preferences.flush();
        } catch(Exception e) {
            System.out.println("KaiConfig:"+e);
        }
    }
    
    public void storeWindowSizePosition(int heigth, int width, double x, double y) {
        preferences.putInt("WINDOWHEIGTH", heigth);
        preferences.putInt("WINDOWWIDTH", width);
        preferences.putInt("WINDOWX", (int)x);
        preferences.putInt("WINDOWY", (int)y);
    }
}
