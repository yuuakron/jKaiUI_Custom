/*
 * Game.java
 *
 * Created on November 21, 2004, 10:56 PM
 */

package pt.jkaiui.core;

/**
 *
 * @author  pedro
 */
public class Game extends KaiObject{
    
    /** Creates a new instance of Game */
    public Game() {
    }
    
    public Game(String name){
        super(name);
    }
    
}
