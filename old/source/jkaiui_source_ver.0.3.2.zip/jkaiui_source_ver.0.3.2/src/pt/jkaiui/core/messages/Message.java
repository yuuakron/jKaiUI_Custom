/*
 * Message.java
 *
 * Created on November 21, 2004, 12:43 AM
 */

package pt.jkaiui.core.messages;

/**
 *
 * @author  pedro
 */
public abstract class Message {
    
    /** Creates a new instance of Message */
    public Message() {
    }
    
}
