/*
 * UnsupportedMessageException.java
 *
 * Created on November 22, 2004, 7:10 PM
 */

package pt.jkaiui.core.messages;

/**
 *
 * @author  pedro
 */
public class UnsupportedMessageException extends Exception {
    
    /** Creates a new instance of UnsupportedMessageException */
    public UnsupportedMessageException() {
        super();
    }
    
}
