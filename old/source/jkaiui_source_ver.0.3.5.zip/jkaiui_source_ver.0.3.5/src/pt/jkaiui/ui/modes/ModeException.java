/*
 * ModeException.java
 *
 * Created on November 21, 2004, 12:45 AM
 */

package pt.jkaiui.ui.modes;

/**
 *
 * @author  pedro
 */
public class ModeException extends Exception {
    
    
    private static final long serialVersionUID = 123414;
    
    /** Creates a new instance of ModeException */
    public ModeException() {
    }
    
}
