/*
 * InMessage.java
 *
 * Created on November 27, 2004, 8:57 PM
 */

package pt.jkaiui.core;

/**
 *
 * @author  pedro
 */
public class OutMessage extends ChatMessage{
    
    /** Creates a new instance of InMessage */
    public OutMessage() {
    }
    
}
