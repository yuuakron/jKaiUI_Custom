/*
 * I_OutMessage.java
 *
 * Created on November 22, 2004, 7:12 PM
 */

package pt.jkaiui.manager;

/**
 *
 * @author  pedro
 */
public interface I_OutMessage {
    
    public String send();
    
}
