/*
 * JMyPanel.java
 *
 * Created on December 1, 2004, 9:00 PM
 */

package pt.jkaiui.ui.modes;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JPanel;
import javax.swing.Box;

/**
 *
 * @author  pedro
 */
public class KaiListPanel extends JPanel{
    
    
    
    Color	_theColor;
    Color	_theBack;
    
    private javax.swing.JLabel jLabelIcon;
    private javax.swing.JLabel jLabelName;
    private javax.swing.JLabel jLabelBase;
    private javax.swing.JLabel jLabelC1;
    private javax.swing.JLabel jLabelC2;
    private JPanel centerPanel;
    
    public KaiListPanel(){
        
        // Border
        setBorder(BorderFactory.createMatteBorder(1,0,0,0,new Color(220,220,220)));
        
        jLabelIcon = new javax.swing.JLabel();
        jLabelName = new javax.swing.JLabel();
        jLabelBase = new javax.swing.JLabel();
        jLabelC1 = new javax.swing.JLabel();
        jLabelC2 = new javax.swing.JLabel();
        
        BorderLayout layout = new BorderLayout();
        layout.setHgap(10);
        layout.setVgap(10);
        setLayout(layout);
        
        // Icon
        add(jLabelIcon, java.awt.BorderLayout.WEST);
        
        // Center Panel
        
        centerPanel = new JPanel();
        centerPanel.setLayout(new GridLayout(5,1));        

        centerPanel.setOpaque(false);
        
        add(centerPanel,BorderLayout.CENTER);

        // Formatting:
        jLabelBase.setFont(new java.awt.Font("SansSerif", 0, 9));
        jLabelBase.setForeground(new Color(10,10,10));
        jLabelC1.setFont(new java.awt.Font("SansSerif", 0, 9));
        jLabelC1.setForeground(new Color(10,10,10));
        jLabelC2.setFont(new java.awt.Font("SansSerif", 0, 9));
        jLabelC2.setForeground(new Color(10,10,10));
     
        centerPanel.add(new Box.Filler(new Dimension(10,10), new Dimension(10,10), new Dimension(10,10)));
        centerPanel.add(jLabelName);
        centerPanel.add(jLabelBase);
        centerPanel.add(jLabelC1);
        centerPanel.add(jLabelC2);

        //centerPanel.add(rightPanel,BorderLayout.EAST);
        
    }
    public Insets getInsets(){
        
        return new Insets(0,3,0,3);
        
    }
    
    public KaiListPanel(Color theColor) {
        _theColor = theColor;
        _theBack = Color.white;
    }
    
    
    public void setColor(Color theColor){
        _theColor = theColor;
    }
    
    public void setBackground(boolean selected){
        
        
        if (selected){
	    _theBack = new Color(255,170,0);
        } else {
            _theBack = Color.white;
        }
        
        setBackground(_theBack);
        repaint();
    }
    
    public void setIcon(Icon icon){
        
        jLabelIcon.setIcon(icon);
    }
    
    public void setText(String text){
        
        jLabelName.setText(text);
//        setToolTipText(text);
    }
    
    public void setDescription(String text){
        
        jLabelBase.setText(text);
        setToolTipText(text);
    }
    
    public void setC1(String text){
        
        jLabelC1.setText(text);
    }
    
    public void setC2(String text){
        
        jLabelC2.setText(text);
    }
}
