/*
 * ChatManager.java
 *
 * Created on November 27, 2004, 9:05 PM
 */
package pt.jkaiui.manager;

import java.net.URL;
import java.text.DateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.logging.Logger;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.swing.ImageIcon;
import javax.swing.JTabbedPane;
import pt.jkaiui.JKaiUI;
import pt.jkaiui.core.ChatMessage;
import pt.jkaiui.core.InMessage;
import pt.jkaiui.core.KaiString;
import pt.jkaiui.core.OutMessage;
import pt.jkaiui.core.User;
import pt.jkaiui.core.messages.ArenaPMOut;
import pt.jkaiui.core.messages.ChatOut;
import pt.jkaiui.core.messages.PMOut;
import pt.jkaiui.tools.log.ConfigLog;
import pt.jkaiui.ui.ChatPanel;
import pt.jkaiui.ui.modes.MessengerModeListModel;

/**
 *
 * @author  pedro
 */
public class ChatManager {

    public static final String GENERAL_CHAT = "\1";
    private static Logger _logger;
    private Hashtable chatsTable;
    private String url;
    private final String[] COLORS = {"#CCCCCC", "#B7FFF1", "#FFE8A9", "#FF7568", "#FFB3CC", "#FFB7FF", "#81C182", "#C6FF5C", "#C8EFFF", "#CEEBFF", "#979EC1", "#BBBBBB", "#BEDEEA"};
    private final ImageIcon NOTIFY_ICON = new ImageIcon(getClass().getResource("/pt/jkaiui/ui/resources/notify.png"));
    private final ImageIcon UNNOTIFY_ICON = new ImageIcon(getClass().getResource("/pt/jkaiui/ui/resources/unnotify.png"));
    private final URL MessageSoundUrl = getClass().getResource("/pt/jkaiui/ui/resources/sound/message.wav");

    /** Creates a new instance of ChatManager */
    public ChatManager() {
        init();
    }

    private void init() {

        _logger = ConfigLog.getLogger(this.getClass().getName());

        ChatPanel chat = new ChatPanel();
        chat.setName(java.util.ResourceBundle.getBundle("pt/jkaiui/ui/Bundle").getString("LBL_GeneralChat"));
        chat.setClosable(false);
        chat.addToMainUI();

        // We need to enable then disable to init the icon
        disableIcon(chat);


        // Putting generic chat in "null" position
        chatsTable = new Hashtable();
        chatsTable.put(GENERAL_CHAT, chat);



        // Load local info!
        String className = this.getClass().getName().replace('.', '/');
        String classPath = this.getClass().getResource("/" + className + ".class").toString();
        String urls[] = classPath.split(className + ".class");
        url = urls[0].substring(0, urls[0].length() - 1);

        //_logger.fine("URL (this should point to jar file:" + url);
    }

    public void processMessage(ChatMessage msg) {

        if (msg instanceof InMessage) {
            processInMessage((InMessage) msg);
        } else if (msg instanceof OutMessage) {
            processOutMessage((OutMessage) msg);
        }

    }

    //htmlencode�֐��@���Ȃ�Ă��Ƃ�
    private String HtmlUnicodeencode(String s, int radix) {
        StringBuffer sb = new StringBuffer("");
        char ch[] = s.toCharArray();
        for (int i = 0; i < ch.length; i++) {
            if (Character.getNumericValue(ch[i]) >= 1) {
                sb.append(ch[i]);
            } else if (Character.isWhitespace(ch[i])) {
                sb.append(ch[i]);
            } else {
                sb.append("&#");
                if (radix == 16) {
                    sb.append("x");
                }
                sb.append(Integer.toString(ch[i], radix) + ";");
            }
        }
        return sb.toString();
    }

    //htmldecode�֐�
    public String HtmlUnicodedecode(String encoded_str, int radix) {
        String retStr = "";
        encoded_str = encoded_str.replaceAll("\\&amp\\;", "&");
        encoded_str = encoded_str.replaceAll("\\&quot\\;", "\"");
        encoded_str = encoded_str.replaceAll("\\&lt\\;", "<");
        encoded_str = encoded_str.replaceAll("\\&gt\\;", ">");
        encoded_str = encoded_str.replaceAll("\\&nbsp\\;", " ");
        for (int i = 0; i < encoded_str.length(); i++) {
            if (encoded_str.charAt(i) != '&') {
                retStr += encoded_str.charAt(i);
                continue;
            }
            int index = encoded_str.indexOf(";", i);
            if (index < 0) {
                continue;
            }
            String str2 = encoded_str.substring(i, index);
            str2 = str2.replaceAll("\\&", "");
            str2 = str2.replaceAll("\\#", "");
            int utf16_code = Integer.parseInt(str2, radix);
            byte[] char_set = new byte[2];
            char_set[0] = (byte) (utf16_code >> 8);
            char_set[1] = (byte) (utf16_code & 255);
            try {
                String new_str = new String(char_set, "UTF-16");
                retStr += new_str;
            } catch (Exception e) {
            }

            i = index;
        }
        return retStr;
    }

    private void processInMessage(InMessage msg) {

        ChatPanel panel = null;

        if (msg.getType() == ChatMessage.PUBLIC_MESSAGE) {

            // get general arena
            panel = (ChatPanel) chatsTable.get(GENERAL_CHAT);

        } else if (msg.getType() == ChatMessage.PRIVATE_MESSAGE) {

            panel = getOrCreatePanel(msg.getUser().getUser());

//            if (JKaiUI.getConfig().getHtmlUnicode()) {
            //�f�R�[�h�̏ꍇ�͂��ł��@�\on
                try {
                    //PM�̏ꍇhtml�f�R�[�h����
                    msg.setMessage(HtmlUnicodedecode(msg.getMessage(), 10));
                } catch (Exception e) {
                }
//            }
            
            //PM�������Ƃ��̂݉����Ȃ炷�p�ɕύX
            if (JKaiUI.getConfig().getPlayMessageSound() &&
                    (JKaiUI.getConfig().getPlaySoundTiming() == 2) && 
                    (userIsFriend(msg.getUser()))){
                playMessageSound();
            }
        }

        if (panel == null) {
            _logger.severe("Could not find tab to write message into");
            return;
        }

        //�قڂ��ׂẴ`���b�g�ŉ���炷
        if (JKaiUI.getConfig().getPlayMessageSound() && !msg.getUser().getUser().equalsIgnoreCase("kai orbital mesh")
                && (JKaiUI.getConfig().getPlaySoundTiming() == 1)) {
            playMessageSound();
        }
        //�t�����h�̔������ɉ����Ȃ炷�p�ɕύX
        if (JKaiUI.getConfig().getPlayMessageSound()
                && (JKaiUI.getConfig().getPlaySoundTiming() == 4)
                && (userIsFriend(msg.getUser()))) {
            playMessageSound();
        }

        panel.write(formatInMessage(msg));

        // Notify if not selected
        enableIconIfSelected(panel);

    }

    private String formatInMessage(InMessage msg) {

        return formatMessage(msg.getUser().getUser(), getColor(msg.getUser().getUser()), encodeMessage(msg.getMessage()));

    }

    private void processOutMessage(OutMessage msg) {

        ChatPanel panel = null;

        if (msg.getType() == ChatMessage.PUBLIC_MESSAGE) {

            // get general arena
            panel = (ChatPanel) chatsTable.get(GENERAL_CHAT);

            ChatOut chat = new ChatOut();
            chat.setMessage(new KaiString(msg.getMessage()));

            JKaiUI.getManager().getExecuter().execute(chat);

        } else if (msg.getType() == ChatMessage.PRIVATE_MESSAGE) {

            User user = msg.getUser();

            PMOut pmOut = new PMOut();
            ArenaPMOut arenaPmOut = new ArenaPMOut();

            if (JKaiUI.getConfig().getHtmlUnicode()) {
                try {
                    //PM�̏ꍇ�AHTML�G���R�[�h������
                    msg.setMessage(HtmlUnicodeencode(msg.getMessage(), 10));
                } catch (Exception e) {
                }
            }
            
            panel = getOrCreatePanel(msg.getUser().getUser());

            if (!userIsFriend(user)) {
                // ArenaPM
                arenaPmOut.setUser(new KaiString(msg.getUser().getUser()));
                arenaPmOut.setMessage(new KaiString(msg.getMessage()));

                JKaiUI.getManager().getExecuter().execute(arenaPmOut);

            } else {
                // PM
                pmOut.setUser(new KaiString(msg.getUser().getUser()));
                pmOut.setMessage(new KaiString(msg.getMessage()));

                JKaiUI.getManager().getExecuter().execute(pmOut);
            }

            if (JKaiUI.getConfig().getHtmlUnicode()) {
                try {
                    //PM�̏ꍇ�AHTML�f�R�[�h������
                    msg.setMessage(HtmlUnicodedecode(msg.getMessage(), 10));
                } catch (Exception e) {
                }
            }
        }

        if (panel == null) {
            _logger.severe("Could not find tab to write message into");
            return;
        }

        panel.write(formatOutMessage(msg));
    }

    private String formatOutMessage(OutMessage msg) {

        return formatMessage(JKaiUI.getConfig().getTag(), "#ffaaaa", encodeMessage(msg.getMessage()));
    }

    private String formatMessage(String user, String color, String msg) {

        String out = "<table style=\"padding:2px;width:100%;font-family:Dialog;font-size:"+JKaiUI.getConfig().getChatFontSize()+"px\"><tr style=\"background-color:" + color + "\"><td>" + user + "</td><td align=\"right\">";
        if (JKaiUI.getConfig().getShowTimestamps()) {
            Date dat = new Date();
            String stime = DateFormat.getTimeInstance().format(dat);
            out += stime;
        }
        out += "</td></tr><tr><td colspan=2>" + msg + "</td></tr></table>";
        return out;

    }

    private String encodeMessage(String s) {

        s = s.replaceAll("&", "&amp;");
        s = s.replaceAll(">", "&gt;");
        s = s.replaceAll("<", "&lt;");

        //s = s.replaceAll(":\\)","<img src=\"jar:file:/home/pedro/tex/kai/jkaiui/dist/jKaiUI.jar!/pt/jkaiui/ui/resources/emoticons/smile.png\">");


        s = s.replaceAll(":\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/smile.png\">");
        s = s.replaceAll(":\\(", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/sad.png\">");
        s = s.replaceAll(":\\*", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/kiss.png\">");
        s = s.replaceAll(":p", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/tongue.png\">");
        s = s.replaceAll(":@", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/angry.png\">");
        s = s.replaceAll(":\\[", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/bat.png\">");
        s = s.replaceAll("\\(B\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/beer.png\">");
        s = s.replaceAll("\\(\\^\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/cake.png\">");
        s = s.replaceAll("\\(o\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/clock.png\">");
        s = s.replaceAll("\\(D\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/cocktail.png\">");
        s = s.replaceAll(":\\|", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/confused.png\">");
        s = s.replaceAll(":'\\(", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/cry.png\">");
        s = s.replaceAll("\\(D\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/cocktail.png\">");
        s = s.replaceAll("\\(C\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/cup.png\">");
        s = s.replaceAll(":\\$", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/embarassed.png\">");
        s = s.replaceAll("\\(~\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/film.png\">");
        s = s.replaceAll("\\(I\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/lightbulb.png\">");
        s = s.replaceAll("\\(8\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/note.png\">");
        s = s.replaceAll(":o", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/omg.png\">");
        s = s.replaceAll("\\(g\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/present.png\">");
        s = s.replaceAll("\\(W\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/rose.png\">");
        s = s.replaceAll("8\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/shade.png\">");
        s = s.replaceAll("\\(\\*\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/star.png\">");
        s = s.replaceAll(":D", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/teeth.png\">");
        s = s.replaceAll("\\(Y\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/thumbs_up.png\">");
        s = s.replaceAll("\\(N\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/thumbs_down.png\">");
        s = s.replaceAll("\\(U\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/unlove.png\">");
        s = s.replaceAll(";\\)", "<img src=\"" + url + "/pt/jkaiui/ui/resources/emoticons/wink.png\">");

        return s;

    }

    private String getColor(String s) {

        char[] array = s.toCharArray();

        int sum = 0;

        for (int i = 0; i < array.length; i++) {

            sum += array[i];

        }

        String color = COLORS[sum % COLORS.length];
        //_logger.fine("Color: " + color );
        return color;

    }

    private ChatPanel getOrCreatePanel(String name) {


        ChatPanel panel = null;

        if (chatsTable.get(name) == null) {

            //PM�p�l�����J�����ꍇ�ɉ���炷�悤�ɕύX
            if (JKaiUI.getConfig().getPlayMessageSound()
                    && (JKaiUI.getConfig().getPlaySoundTiming() == 3)) {
                playMessageSound();
            }

            panel = new ChatPanel();
            panel.setName(name);
            panel.addToMainUI();
            enableIcon(panel);

            chatsTable.put(name, panel);
        } else {
            panel = (ChatPanel) chatsTable.get(name);
        }

        return panel;
    }

    public void closeChat(ChatPanel chat) {

        // Remove from hash

        chatsTable.remove(chat.getName());

        chat.removeFromMainUI();

    }

    public void openChat(User user) {

        getOrCreatePanel(user.getUser());

    }

    public void enterRoom(String arena) {

        // Notify that user has entered the arena
        ChatPanel panel = (ChatPanel) chatsTable.get(GENERAL_CHAT);

        panel.write("<div style=\"color:black; font-size:"+JKaiUI.getConfig().getSystemFontSize()+"px;\"> -- " + java.util.ResourceBundle.getBundle("pt/jkaiui/ui/Bundle").getString("MSG_CurrentArena") + ": " + arena + "</div>");
        JKaiUI.getMainUI().setTitle("JKaiUI: " + arena);

    }

    public void joinsRoom(String user) {

        // Notify that user has entered the arena
        ChatPanel panel = (ChatPanel) chatsTable.get(GENERAL_CHAT);

        //panel.write("<font size=\"-1\" color=\"#cccccc\">   --&gt; "+ java.util.ResourceBundle.getBundle("pt/jkaiui/ui/Bundle").getString("MSG_JoinsChat") +": " + user + "</font>" );
        //_logger.config("  --&gt; "+ java.util.ResourceBundle.getBundle("pt/jkaiui/ui/Bundle").getString("MSG_JoinsChat") +": " + user );

    }

    public void leavesRoom(String user) {

        // Notify that user has entered the arena
        ChatPanel panel = (ChatPanel) chatsTable.get(GENERAL_CHAT);

        //panel.write("<font size=\"-1\" color=\"#cccccc\">   &lt;-- "+ java.util.ResourceBundle.getBundle("pt/jkaiui/ui/Bundle").getString("MSG_LeavesChat") +": " + user + "</font>" );
        //_logger.config("  &lt;-- "+ java.util.ResourceBundle.getBundle("pt/jkaiui/ui/Bundle").getString("MSG_LeavesChat") +": " + user );


    }

    private boolean userIsFriend(User user) {

        MessengerModeListModel model = (MessengerModeListModel) JKaiUI.getMessengerMode().list.getModel();
        return model.contains(user);

    }

    public void enableIcon(ChatPanel panel) {

        JTabbedPane pane = JKaiUI.getMainUI().jTabbedPane;
        pane.setIconAt(pane.indexOfComponent(panel), NOTIFY_ICON);

    }

    public void disableIcon(ChatPanel panel) {

        JTabbedPane pane = JKaiUI.getMainUI().jTabbedPane;
        pane.setIconAt(pane.indexOfComponent(panel), UNNOTIFY_ICON);

    }

    public void enableIconIfSelected(ChatPanel panel) {

        JTabbedPane pane = JKaiUI.getMainUI().jTabbedPane;
        if (!pane.getSelectedComponent().equals(panel)) {
            enableIcon(panel);
        }

    }

    private void playMessageSound() {

        try {
            AudioInputStream ais = AudioSystem.getAudioInputStream(MessageSoundUrl);
            AudioFormat format = ais.getFormat();
            DataLine.Info info = new DataLine.Info(Clip.class, ais.getFormat(),
                    ((int) ais.getFrameLength() * format.getFrameSize()));
            Clip cl = (Clip) AudioSystem.getLine(info);
            cl.open(ais);
            cl.start();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}
