/*
 * KaiConfig.java
 *
 * Created on November 18, 2004, 4:23 PM
 */

package pt.jkaiui.core;
import java.util.prefs.Preferences;
import java.io.File;
import java.util.Collections;
import java.util.Vector;

/**
 *
 * @author  pedro
 */
public class KaiConfig {
    
    private static final String PREFERENCES = "/pt/jkaiui";
    
    private static Preferences preferences;
    
    /** Holds value of the NTP server */
    private String NTPServer;
    
    /** Holds value of the avatar cache location */
    private String avatarCacheLocation;
    
    private int cacheDays;
    private boolean showTimestamps;
    private boolean sendStatsPermission;
    private boolean showServerStats;
    private boolean storeWindowSizePosition;
    private int WindowHeigth;
    private int WindowWidth;
    private int WindowX;
    private int WindowY;
    private boolean playMessageSound;
    
    /** Holds value of the avatar cache location */
    private boolean engineAutomaticallyDetected;
    
    /** Holds value of property tag. */
    private String tag;
    
    /** Holds value of property password. */
    private String password;
    
    /** Holds value of property host. */
    private String host;
    
    /** Holds value of property port. */
    private int port;
    
    private String BookmarksAtStart;


    //1:Allchat 2:AllPM  3:when PM open 4: friend
    private int playSoundTiming;
    
    //
    private boolean HtmlUnicode;
    private boolean URLDecode;
    
    private boolean AllLog;
    private boolean ChatLog;
    private boolean UserLog;
    private boolean RoomLog;
    private boolean FriendLog;

    private String AllLogFile;
    private String ChatLogFile;
    private String UserLogFile;
    private String RoomLogFile;
    private String FriendLogFile;
    
    private String AllLogPattern;
    private String ChatLogPattern;
    private String UserLogPattern;
    private String RoomLogPattern;
    private String FriendLogPattern;
 
    private int ChatFontSize;
    private int SystemFontSize;
    
    /** Creates a new instance of KaiConfig */
    public KaiConfig() {
    }

    ////////////////////////////
    ////   GETTERS
    //////////////
    
    /** Getter for property tag.
     * @return Value of property tag. */
    public String getTag() {
        return this.tag;
    }
    
    /** Getter for property password.
     * @return Value of property password. */
    public String getPassword() {
        return this.password;
    }
    
    /** Getter for property host.
     * @return Value of property host. */
    public String getHost() {
        return this.host;
    }
    
    /** Getter for property port.
     * @return Value of property port. */
    public int getPort() {
        return this.port;
    }
    
    /** Getter for property NTPServer.
     * @return Value of property NTPServer. */
    public String getNTPServer() {
        return this.NTPServer;
    }
    
    /** Getter for property AVATARCACHE.
     * @return Value of property AVATARCACHE. */
    public String getAvatarCacheLocation() {
        return this.avatarCacheLocation;
    }
    
    public boolean getEngineAutomaticallyDetected() {
        return this.engineAutomaticallyDetected;
    }
    
    public int getCacheDays() {
        return cacheDays;
    }
    
    public boolean getSendStatsPermission() {
        return sendStatsPermission;
    }
    
    public boolean getShowTimestamps() {
        return showTimestamps;
    }
    
    public String getBookmarksAtStart() {
        return BookmarksAtStart;
    }
    
    public boolean getShowServerStats() {
        return showServerStats;
    }
    
    public boolean getStoreWindowSizePosition() {
        return storeWindowSizePosition;
    }
    
    public int getWindowHeigth() {
        return WindowHeigth;
    }
    
    public int getWindowWidth() {
        return WindowWidth;
    }
    
    public int getWindowX() {
        return WindowX;
    }
    
    public int getWindowY() {
        return WindowY;
    }

    
    
    public boolean getPlayMessageSound() {
        return playMessageSound;
    }
    
    public int getPlaySoundTiming(){
        return playSoundTiming;
    }
    
    public boolean getHtmlUnicode() {
        return HtmlUnicode;
    }

    public boolean getURLDecode() {
        return URLDecode;
    }
    
    public boolean getAllLog() {
        return AllLog;
    }

    public String getAllLogFile() {
        return AllLogFile;
    }

    public String getAllLogPattern() {
        return AllLogPattern;
    }

    public int getChatFontSize() {
        return ChatFontSize;
    }

    public boolean getChatLog() {
        return ChatLog;
    }

    public String getChatLogFile() {
        return ChatLogFile;
    }

    public String getChatLogPattern() {
        return ChatLogPattern;
    }

    public boolean getFriendLog() {
        return FriendLog;
    }

    public String getFriendLogFile() {
        return FriendLogFile;
    }

    public String getFriendLogPattern() {
        return FriendLogPattern;
    }

    public boolean getRoomLog() {
        return RoomLog;
    }

    public String getRoomLogFile() {
        return RoomLogFile;
    }

    public String getRoomLogPattern() {
        return RoomLogPattern;
    }

    public int getSystemFontSize() {
        return SystemFontSize;
    }

    public boolean getUserLog() {
        return UserLog;
    }

    public String getUserLogFile() {
        return UserLogFile;
    }

    public String getUserLogPattern() {
        return UserLogPattern;
    }
    
    ////////////////////////////
    ////   SETTERS
    //////////////
    
    /** Setter for property tag.
     * @param tag New value of property tag. */
    public void setTag(String tag) {
        this.tag = tag;
    }
    
    /** Setter for property password.
     * @param password New value of property password. */
    public void setPassword(String password) {
        this.password = password;
    }
    
    /** Setter for property host.
     * @param host New value of property host. */
    public void setHost(String host) {
        this.host = host;
    }
    
    /** Setter for property port.
     * @param port New value of property port. */
    public void setPort(int port) {
        this.port = port;
    }
    
    /** Setter for property NTPServer.
     * @param server New value of the NTPServer property*/
    public void setNTPServer(String server) {
        this.NTPServer = server;
    }
    
    public void setAvatarCacheLocation(String location) {
        this.avatarCacheLocation = location;
    }
    
    public void setEngineAutomaticallyDetected(boolean value) {
        this.engineAutomaticallyDetected = value;
    }
    
    public void setCacheDays(int days) {
        cacheDays = days;
    }
    
    public void setSendStatsPermission(boolean permission) {
        sendStatsPermission = permission;
    }
    
    public void setShowTimestamps(boolean value) {
        showTimestamps = value;
    }
    
    public void setShowServerStats(boolean value) {
        showServerStats = value;
    }
    
    public void setStoreWindowSizePosition(boolean value) {
        storeWindowSizePosition = value;
    }
    
    public void setPlayMessageSound(boolean value) {
        playMessageSound = value;
    }

    
    
    public void setPlaySoundTiming(int playSoundTiming) {
        this.playSoundTiming = playSoundTiming;
    }
    
    public void setHtmlUnicode(boolean HtmlUnicode) {
        this.HtmlUnicode = HtmlUnicode;
    }
    
    public void setURLDecode(boolean URLDecode) {
        this.URLDecode = URLDecode;
    }
    
    public void setAllLog(boolean AllLog) {
        this.AllLog = AllLog;
    }

    public void setAllLogFile(String AllLogFile) {
        this.AllLogFile = AllLogFile;
    }

    public void setAllLogPattern(String AllLogPattern) {
        this.AllLogPattern = AllLogPattern;
    }

    public void setChatFontSize(int ChatFontSize) {
        this.ChatFontSize = ChatFontSize;
    }

    public void setChatLog(boolean ChatLog) {
        this.ChatLog = ChatLog;
    }

    public void setChatLogFile(String ChatLogFile) {
        this.ChatLogFile = ChatLogFile;
    }

    public void setChatLogPattern(String ChatLogPattern) {
        this.ChatLogPattern = ChatLogPattern;
    }

    public void setFriendLog(boolean FriendLog) {
        this.FriendLog = FriendLog;
    }

    public void setFriendLogFile(String FriendLogFile) {
        this.FriendLogFile = FriendLogFile;
    }

    public void setFriendLogPattern(String FriendLogPattern) {
        this.FriendLogPattern = FriendLogPattern;
    }

    public void setRoomLog(boolean RoomLog) {
        this.RoomLog = RoomLog;
    }

    public void setRoomLogFile(String RoomLogFile) {
        this.RoomLogFile = RoomLogFile;
    }

    public void setRoomLogPattern(String RoomLogPattern) {
        this.RoomLogPattern = RoomLogPattern;
    }

    public void setSystemFontSize(int SystemFontSize) {
        this.SystemFontSize = SystemFontSize;
    }

    public void setUserLog(boolean UserLog) {
        this.UserLog = UserLog;
    }

    public void setUserLogFile(String UserLogFile) {
        this.UserLogFile = UserLogFile;
    }

    public void setUserLogPattern(String UserLogPattern) {
        this.UserLogPattern = UserLogPattern;
    }
    
    
    
    public void readConfig(){
        
        preferences = Preferences.userRoot().node(PREFERENCES);
        
        this.setTag(preferences.get("TAG",""));
        this.setPassword(preferences.get("PASSWORD",""));
        this.setHost(preferences.get("HOST","127.0.0.1"));
        this.setPort(preferences.getInt("PORT",34522));
        this.setNTPServer(preferences.get("NTPSERVER", "ntp1.ptb.de"));
        this.setAvatarCacheLocation(preferences.get("AVATARCACHE",
        System.getProperty("user.home") + File.separator + ".java" + File.separator + ".jkaiui_cache"));
        this.setEngineAutomaticallyDetected(preferences.getBoolean("AUTOMATICALLYDETECTED", true));
        this.setCacheDays(preferences.getInt("CACHEDAYS", 3));
        this.setSendStatsPermission(preferences.getBoolean("ALLOWSTATISTICS", true));
        this.setShowTimestamps(preferences.getBoolean("SHOWTIMESTAMPS", false));
        this.BookmarksAtStart = preferences.get("BOOKMARKS", "");
        setStoreWindowSizePosition(preferences.getBoolean("STOREWINDOWSIZEPOSITION", false));
        setShowServerStats(preferences.getBoolean("SHOWSERVERSTATS", false));
        this.WindowHeigth = preferences.getInt("WINDOWHEIGTH", 500);
        this.WindowWidth = preferences.getInt("WINDOWWIDTH", 200);
        this.WindowX = preferences.getInt("WINDOWX", 0);
        this.WindowY = preferences.getInt("WINDOWY", 0);
        this.playMessageSound = preferences.getBoolean("PLAYMESSAGESOUND", true);
        
        this.playSoundTiming = preferences.getInt("PLAYSOUNDTIMING", 4);
        this.HtmlUnicode = preferences.getBoolean("HtmlEncode", true);
        this.URLDecode = preferences.getBoolean("URLDecode", true);
        
        this.AllLog = preferences.getBoolean("AllLog",false);
        this.ChatLog = preferences.getBoolean("ChatLog", false);
        this.UserLog = preferences.getBoolean("UserLog", false);
        this.RoomLog = preferences.getBoolean("RoomLog", false);
        this.FriendLog = preferences.getBoolean("FriendLog",false);
        
        this.AllLogFile = preferences.get("AllLogFile", "./log/Alllog-%Y%M%D.txt");
        this.ChatLogFile = preferences.get("ChatLogFile", "./log/Chatlog-%Y%M%D.txt");
        this.UserLogFile = preferences.get("UserLogFile", "./log/Userlog-%Y%M%D.txt");
        this.RoomLogFile = preferences.get("RoomLogFile", "./log/Roomlog-%Y%M%D.txt");
        this.FriendLogFile = preferences.get("FriendLogFile", "./log/Friendlog-%Y%M%D.txt");

        this.AllLogPattern = preferences.get("AllLogPattern", "%T;%M");
        this.ChatLogPattern = preferences.get("ChatLogPattern", "%T;%K;%R;%S;%M");
        this.UserLogPattern = preferences.get("UserLogPattern", "%N");
        this.RoomLogPattern = preferences.get("RoomLogPattern", "%V;%C;%S;%P;%M;%D");
        this.FriendLogPattern = preferences.get("FriendLogPattern", "%T;%K;%N");

        this.ChatFontSize = preferences.getInt("ChatFontSize", 12);
        this.SystemFontSize = preferences.getInt("SystemFontSize", 10);
    }
    
    public void saveConfig(){
        
        preferences.put("TAG",this.getTag());
        preferences.put("PASSWORD",this.getPassword());
        preferences.put("HOST",this.getHost());
        preferences.putInt("PORT",this.getPort());
        preferences.put("NTPSERVER", this.getNTPServer());
        preferences.putBoolean("AUTOMATICALLYDETECTED", this.getEngineAutomaticallyDetected());
        preferences.putInt("CACHEDAYS", this.getCacheDays());
        preferences.putBoolean("ALLOWSTATISTICS", this.getSendStatsPermission());
        preferences.putBoolean("SHOWTIMESTAMPS", this.getShowTimestamps());
        preferences.putBoolean("SHOWSERVERSTATS", this.getShowServerStats());
        preferences.putBoolean("STOREWINDOWSIZEPOSITION", this.getStoreWindowSizePosition());
        preferences.putBoolean("PLAYMESSAGESOUND", this.getPlayMessageSound());
        
        preferences.putInt("PLAYSOUNDTIMING", this.getPlaySoundTiming());
        preferences.putBoolean("HtmlUnicode", this.getHtmlUnicode());
        preferences.putBoolean("URLDecode", this.getURLDecode());
       
        preferences.putBoolean("AllLog", this.getAllLog());
        preferences.putBoolean("ChatLog", this.getChatLog());
        preferences.putBoolean("UserLog", this.getUserLog());
        preferences.putBoolean("RoomLog", this.getRoomLog());
        preferences.putBoolean("FriendLog", this.getFriendLog());
        
        preferences.put("AllLogFile", this.getAllLogFile());
        preferences.put("ChatLogFile", this.getChatLogFile());
        preferences.put("UserLogFile", this.getUserLogFile());
        preferences.put("RoomLogFile", this.getRoomLogFile());
        preferences.put("FriendLogFile", this.getFriendLogFile());
        
        preferences.put("AllLogPattern", this.getAllLogPattern());
        preferences.put("ChatLogPattern", this.getChatLogPattern());
        preferences.put("UserLogPattern", this.getUserLogPattern());
        preferences.put("RoomLogPattern", this.getRoomLogPattern());
        preferences.put("FriendLogPattern", this.getFriendLogPattern());

        preferences.putInt("ChatFontSize", this.getChatFontSize());
        preferences.putInt("SystemFontSize", this.getSystemFontSize());
    }
    
    public void saveBookmarks(Vector Bookmarks) {
        Collections.sort(Bookmarks);
        preferences.put("BOOKMARKS", Bookmarks.toString());
        try {
            preferences.flush();
        } catch(Exception e) {}
    }
    
    public void storeWindowSizePosition(int heigth, int width, double x, double y) {
        preferences.putInt("WINDOWHEIGTH", heigth);
        preferences.putInt("WINDOWWIDTH", width);
        preferences.putInt("WINDOWX", (int)x);
        preferences.putInt("WINDOWY", (int)y);
    }
}
