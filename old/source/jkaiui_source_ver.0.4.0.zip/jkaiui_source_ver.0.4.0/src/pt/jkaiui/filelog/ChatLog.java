/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.jkaiui.filelog;

import pt.jkaiui.JKaiUI;
        
import java.io.File;

import pt.jkaiui.core.messages.*;
/**
 *
 * @author yuu@akron
 */
public class ChatLog extends Log {

    public ChatLog() {
        this.init();
    }

    protected void init() {
//        System.out.println("chatlog");
        logfile = new File(format(JKaiUI.getConfig().getChatLogFile()));
        super.init();
    }

    public void println(Object chat, Object CurrentArena) {
        if (!datecheck()) {
            update();
        }

        String pattern = JKaiUI.getConfig().getChatLogPattern();
        pattern = pattern.replaceAll("%T", now());
        if (chat instanceof Chat) {
            Chat chattmp = (Chat) chat;
            pattern = pattern.replaceAll("%K", "Chat");
            pattern = pattern.replaceAll("%R", (String) CurrentArena);
            pattern = pattern.replaceAll("%S", chattmp.getUser().decode());
            pattern = pattern.replaceAll("%M", chattmp.getMessage().decode());
        }
        if (chat instanceof ChatOut) {
            ChatOut chattmp = (ChatOut) chat;
            pattern = pattern.replaceAll("%K", "ChatOut");
            pattern = pattern.replaceAll("%R", (String) CurrentArena);
            pattern = pattern.replaceAll("%S", JKaiUI.getConfig().getTag().toString());
            pattern = pattern.replaceAll("%M", chattmp.getMessage().decode());
        }
        logfilepw.println(pattern);
    }

    public void println(Object chat) {
        if (!datecheck()) {
            update();
        }

        String pattern = JKaiUI.getConfig().getChatLogPattern();
        pattern = pattern.replaceAll("%T", now());
        if (chat instanceof PM) {
            PM chattmp = (PM) chat;
            pattern = pattern.replaceAll("%K", "PM");
            pattern = pattern.replaceAll("%R", JKaiUI.getConfig().getTag().toString());
            pattern = pattern.replaceAll("%S", chattmp.getUser().decode());
            pattern = pattern.replaceAll("%M", JKaiUI.getChatManager().HtmlUnicodedecode(chattmp.getMessage().decode(), 10));
        }
        if (chat instanceof PMOut) {
            PMOut chattmp = (PMOut) chat;
            pattern = pattern.replaceAll("%K", "PMOut");
            pattern = pattern.replaceAll("%R", chattmp.getUser().decode());
            pattern = pattern.replaceAll("%S", JKaiUI.getConfig().getTag().toString());
            pattern = pattern.replaceAll("%M", JKaiUI.getChatManager().HtmlUnicodedecode(chattmp.getMessage().decode(), 10));
        }
        if (chat instanceof ArenaPM) {
            ArenaPM chattmp = (ArenaPM) chat;
            pattern = pattern.replaceAll("%K", "ArenaPM");
            pattern = pattern.replaceAll("%R", JKaiUI.getConfig().getTag().toString());
            pattern = pattern.replaceAll("%S", chattmp.getUser().decode());
            pattern = pattern.replaceAll("%M", JKaiUI.getChatManager().HtmlUnicodedecode(chattmp.getMessage().decode(), 10));
        }
        if (chat instanceof ArenaPMOut) {
            ArenaPMOut chattmp = (ArenaPMOut) chat;
            pattern = pattern.replaceAll("%K", "ArenaPMOut");
            pattern = pattern.replaceAll("%R", chattmp.getUser().decode());
            pattern = pattern.replaceAll("%S", JKaiUI.getConfig().getTag().toString());
            pattern = pattern.replaceAll("%M", JKaiUI.getChatManager().HtmlUnicodedecode(chattmp.getMessage().decode(), 10));
        }
        logfilepw.println(pattern);
    }
}
