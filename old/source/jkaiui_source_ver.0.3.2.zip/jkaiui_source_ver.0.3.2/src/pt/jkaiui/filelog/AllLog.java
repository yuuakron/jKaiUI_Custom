/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.jkaiui.filelog;

import pt.jkaiui.JKaiUI;
        
import java.io.File;

/**
 *
 * @author yuu@akron
 */
public class AllLog extends Log{
    public AllLog(){
        this.init();
    }
    
    protected void init(){  
        
//        System.out.println("alllog");
        
        logfile = new File(format(JKaiUI.getConfig().getAllLogFile()));
        super.init();
    }
    
    public void println(String s){
        if(!datecheck()){
            update();
        }
        
        String pattern =  JKaiUI.getConfig().getAllLogPattern();
        pattern = pattern.replaceAll("%T", now());
        pattern = pattern.replaceAll("%M", s);
        
        logfilepw.println(pattern);
    }
}
