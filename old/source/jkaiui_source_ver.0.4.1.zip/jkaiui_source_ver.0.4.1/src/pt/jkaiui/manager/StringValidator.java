/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.jkaiui.manager;
import java.io.*;
import pt.jkaiui.JKaiUI;

/**
 *
 * @author yuu@akron
 */
public class StringValidator {

    private static boolean checkCharacterCode(String str, String encoding) {
        if (str == null) {
            return true;
        }
        
        try {
            byte[] bytes = str.getBytes(encoding);
            return str.equals(new String(bytes, encoding));
        } catch (UnsupportedEncodingException ex) {
            System.out.println("StringValidator:"+ex);
            throw new RuntimeException("�G���R�[�h���̂�����������܂���B", ex);
        }
    }
    
    private static boolean checkCharacterCode(byte[] str, String encoding) {
        if (str == null) {
            return true;
        }

        try {
            String strtmp = new String(str, encoding);
            byte[] bytes = strtmp.getBytes(encoding);
            return strtmp.equals(new String(bytes, encoding));
        } catch (UnsupportedEncodingException ex) {
            System.out.println("StringValidator:" + ex);
            throw new RuntimeException("�G���R�[�h���̂�����������܂���B", ex);
        }
    }
    
    public static boolean isWindows31j(String str) {
        return checkCharacterCode(str, "Windows-31j");
    }

    public static boolean isSJIS(String str) {
        return checkCharacterCode(str, "SJIS");
    }

    public static boolean isEUC(String str) {
        return checkCharacterCode(str, "euc-jp");
    }

    public static boolean isUTF8(String str) {
        return checkCharacterCode(str, "UTF-8");
    }

    public static boolean isWindows31j(byte[] str) {
        return checkCharacterCode(str, "Windows-31j");
    }

    public static boolean isSJIS(byte[] str) {
        return checkCharacterCode(str, "SJIS");
    }

    public static boolean isEUC(byte[] str) {
        return checkCharacterCode(str, "euc-jp");
    }

    public static boolean isUTF8(byte[] str) {
        return checkCharacterCode(str, "UTF-8");
    }

    public static String BytetoString(byte[] str) {
        try {
            if (JKaiUI.getKaiEngineVersion()==null) {
                return new String(str);
            }
            if (JKaiUI.getKaiEngineVersion().equals("7.4.18")) {
                return new String(str, "SJIS");
            }
            if (JKaiUI.getKaiEngineVersion().equals("7.4.22")) {
                String strtmp = new String(str, "utf-8");
                return new String(strtmp.getBytes("SJIS"), "SJIS");
            }
        } catch (Exception e) {
            System.out.println("checkbyte" + e);
        }
        return new String(str);
    }
    

    public static byte[] StringtoByte(String str) {

        try {
            if (JKaiUI.getKaiEngineVersion()==null) {
                return str.getBytes();
            }
            if (JKaiUI.getKaiEngineVersion().equals("7.4.18")) {
                return str.getBytes("SJIS");
            }
            if (JKaiUI.getKaiEngineVersion().equals("7.4.22")) {
                return str.getBytes("utf-8");
            }
        } catch (Exception e) {
            System.out.println("checkstring" + e);
        }
        return str.getBytes();
    }
    
    public static String CheckandReturnCorrectString(byte[] str) {
                
        try {
            if(isSJIS(str)){
//                System.out.println("SJIS");
                return new String(str, "SJIS");
            }
            if (isWindows31j(str)) {
//                System.out.println("31j");
                return new String(str, "Windows-31j");
            }
            if (isUTF8(str)) {
//                System.out.println("UTF8");
                return new String(str, "utf-8");
            }
        } catch (Exception e) {
            System.out.println("checkcorrect" + e);
        }
        return new String(str);
    }
/*    
    public static String ReturnSelectedCodingString(byte[] str, String encoding) {

        if(encoding == null){
            return new String(str);
        }
        
        try {
            return new String(str, encoding);

        } catch (Exception e) {
            System.out.println("checkselected" + e);
            return new String(str);
        }
    }
     * 
     */
}
